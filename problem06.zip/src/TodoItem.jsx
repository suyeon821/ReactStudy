import React,{Fragment, useState} from 'react';
import style from './style.css';
import {BrowserRouter, Route, Switch} from "react-router-dom";
import Detail from './Detail';
import {Link} from "react-router-dom";

const TodoItem = ({todoitem, onUpdate, onDelete}) => {
    let [form, setForm] = useState(todoitem);

    const onChange = (event)=> {
        setForm({
            ...form,
            [event.target.name] : event.target.value
        });
    }
    let [clk, setClk] = useState(true);
    const onOff = (event)=>{
        event.stopPropagation();
event.preventDefault();
        setClk(!clk);
    }
    const update = (event)=>{
        event.stopPropagation();
event.preventDefault();
        onUpdate(todoitem, form);
        onOff();
    }

    const link = () =>{

    }
    
   return (
       
       <div className="Todo">
        {clk ? 

            <Link to ={"/Detail"}>
           <div>
           {todoitem.title}
           <br/>
           {todoitem.body}
           {todoitem.finishedAt}
           <br/>
           <button onClick={onOff}>수정</button><button onClick ={() => {onDelete(todoitem)}}>삭제</button>
            </div>
            </Link>


        :
            <Fragment>
            <input name= "title" value={form.title} onChange={onChange}></input>
                <br/>
                <input name= "body" value={form.body} onChange={onChange}></input>
                <br/>
                <input name= "finishedAt" value={form.finishedAt} onChange={onChange}></input>
                <br/>
            <br/>
            <button onClick={update}>확인</button>
            </Fragment>}
        </div>
   );
}
export default (TodoItem);